// sorts five arrays

outlets = 3;

function bang()
{
	// array1 = [3, 5, 6, 9, 10];
	array1 = [ 2, 3, 7, 9, 10 ];
	array2 = rotateArrayRight(array1, 1);
	array3 = rotateArrayRight(array1, 2);
	array4 = rotateArrayRight(array1, 3);
	array5 = rotateArrayRight(array1, 4);

	array1int = getIntArray(array1).reverse();
	array2int = getIntArray(array2).reverse();
	array3int = getIntArray(array3).reverse();
	array4int = getIntArray(array4).reverse();
	array5int = getIntArray(array5).reverse();

	twodIntArray = [];
	// component = new Array(array1.length);

	for ( var i = 0; i < array1.length; i++ ) {
	// I think I'm trying to do the manual stuff above in a for loop here.
			var rotated = rotateArrayRight(array1, i);
			var component = getIntArray(rotated).reverse();
			twodIntArray.push(component);
	}

	if(desiredOutput == 1) { outlet(1,array1int); outlet(0,array1); }
	else if(desiredOutput == 2) { outlet(1,array2int); outlet(0,array2); }
	else if(desiredOutput == 3) { outlet(1,array3int); outlet(0,array3); }
	else if(desiredOutput == 4) { outlet(1,array4int); outlet(0,array4); }
	else if(desiredOutput == 5) { outlet(1,array5int); outlet(0,array5); }
	else {
		// send out the formatted 2D array
		outputString = show2dArray(twodIntArray);
		sortedString = sort2dArray(twodIntArray, 3);
		sortedString = show2dArray(sortedString);
		outlet(0, array1);
		outlet(1, outputString);
		outlet(2, sortedString);
	}
}

function getIntArray(a) {
	intArray = new Array(a.length - 1);
	for ( var i = 0; i < a.length - 1; i++ ) {
		var theInt = a[a.length-i-1] - a[0];
		// do the music theory absolute value thing
		if (theInt < 0) { theInt = 12-Math.abs(theInt); }
		intArray[i] = theInt;
	}
	return intArray;
}

function rotateArrayRight(a, k) {
	if ( k == 0 ) { return a; }
	var n = a.length;
	const rotated = a.slice(-k).concat(a.slice(0, n-k));
	return rotated;
}

function show2dArray(matrix) {
	rowString = "[ ";
	for (var i = 0; i < matrix.length; i++) {
		rowString += "[ ";
		for (var j = 0; j < matrix[i].length; j++) {
			rowString += matrix[i][j] + " ";
		}
		rowString += "] ";
	}
	rowString += "] ";
	return rowString;
}

function sort2dArray(arr, index) {
	// here we want to sort by the LAST element FIRST
	// so we need to know how large the array is.
	// If there is a TIE with the last element, we will
	// need to sort according to the second-to-last element,
	// and so forth (recursion). If there is a tie all the way
	// to the end, that's OK.
	// The normal form will be the lowest entry (i.e., have
	// the lowest value in the last place, etc.).
	// while (index !== 0) {
		arr.sort(function(a, b) { return a[index] - b[index]; } );
		if ( index == 0 ) { return arr; }
			else { sort2dArray(arr, index-1); }
		// return arr;
	// }
	// sort2dArray(arr, index-1);
}

//==================
// INPUT PROCESSING

function msg_int(v) {
	desiredOutput = v;
	bang();
}
